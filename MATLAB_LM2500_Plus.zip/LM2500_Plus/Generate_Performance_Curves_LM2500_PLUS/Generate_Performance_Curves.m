clearvars
close all

%Started 7/29/2024 to generate part-load results to compare with Haglind
%Need to change trb map files within function_split_shaft_model

trb_filename =  'Scaled_2Stage_HighPqPTrb_4_kg_s'; %TwoStgTurbine_HighPqPTurbine but 4 kg/s bleed
parasitic_losses = 4;%kg/s
mode = 3;%==1 for constant torque and 2 for constant speed, and 3 to match propellor data from USS RAMAGE

error_threshold = 1.5;%Percent, had to increase it since RPM=3600 not chosen even at 80% load 
design_fuel_rate  = 1.934;%kg/s

percent_load_vector = 20:5:100;
N = length(percent_load_vector);%20% to 100% load
power_vector = zeros(N,1);
torque_vector = zeros(N,1);
RPM_vector = zeros(N,1);
brake_torque_vector = zeros(N,1);
brake_RPM_vector = zeros(N,1);
efficiency_vector = zeros(N,1);
mdot_vector = zeros(N,1);
PR_vector = zeros(N,1);
exh_tmptr_vector = zeros(N,1);
trg_in_tmptr_vector = zeros(N,1);
exh_p_vector = zeros(N,1);
fuel_GPH_vector = 3600*264.172*design_fuel_rate.*(percent_load_vector/100)/860;
for index = 1:N
    percent_load = percent_load_vector(index)
    fuel_flow_rate = design_fuel_rate*(percent_load/100);
    [operating_power,operating_torque, effective_RPM,operating_efficiency,operating_mdot,operating_PR,...
        operating_exhaust_tmptr_deg_C,operating_trb_inlet_tmptr_deg_C,operating_exhaust_P_kPa,closest_brake_RPM,closest_brake_torque] ...
        = function_split_shaft_model(fuel_flow_rate,trb_filename,error_threshold,parasitic_losses,mode);
    power_vector(index,1)=      operating_power;
    torque_vector(index,1)=     operating_torque;
    RPM_vector(index,1)=        effective_RPM;
    brake_torque_vector(index,1)=     closest_brake_torque;
    brake_RPM_vector(index,1)=        closest_brake_RPM;
    efficiency_vector(index,1)= operating_efficiency;
    mdot_vector(index,1)=       operating_mdot;
    PR_vector(index,1)=         operating_PR;
    exh_tmptr_vector(index,1)=  operating_exhaust_tmptr_deg_C;
    trg_in_tmptr_vector(index,1)= operating_trb_inlet_tmptr_deg_C;
    exh_p_vector(index,1)=      operating_exhaust_P_kPa;

end

predicted_delivered_power = power_vector*0.99*0.99; %1% loss through reduction gear, and another 1% through seals and beaarings, brake->shaft->delivered
load USS_RAMAGE_data.mat ship_speed_knots delivered_power 
predicted_ship_speed = interp1(delivered_power/1e6, ship_speed_knots, predicted_delivered_power,'linear','extrap');

figure(1),plot(predicted_ship_speed,predicted_delivered_power,'o',ship_speed_knots,delivered_power/1e6,'d');
legend('Predicted','USS Ramage Data');xlabel('Ship Speed [Knots]');ylabel('Delivered Power [MW]');

figure(2),yyaxis left
plot(predicted_ship_speed,efficiency_vector,'x');
xlabel('Ship Speed [Knots]');ylabel('Thermal Efficiency [%]');
figure(2),yyaxis right
plot(predicted_ship_speed,predicted_delivered_power,'o');
xlabel('Ship Speed [Knots]');ylabel('Predicted Power [MW]');

figure(3),plot( 100*abs((RPM_vector-brake_RPM_vector)./brake_RPM_vector),100*abs((torque_vector-brake_torque_vector)./brake_torque_vector),'.');
xlabel('RPM Deviation [%]');ylabel('Torque Deviation [%]');

figure(4),plot(predicted_ship_speed,fuel_GPH_vector,'o');xlabel('Predicted Ship Speed [Knots]');ylabel('Fuel Consumption [GPH]');


save F76_performance_curve_predictions.mat